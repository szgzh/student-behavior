# 学生行为记录系统 - 部署说明

## 快速部署

### 方式一：直接运行（推荐）

1. 上传 `deploy` 文件夹到服务器
2. 执行启动脚本：
```bash
cd deploy
chmod +x start.sh
./start.sh
```

### 方式二：手动启动

```bash
cd deploy
npm install
node dist-server/server.js
```

## 访问地址

启动后访问：`http://your-server-ip:5000`

## 功能说明

- **仪表盘** - 统计概览和排行榜预览
- **学生管理** - 添加/删除学生（删除需密码）
- **行为记录** - 选择学生和行为类型记录（分值固定）
- **积分排行** - 周榜/月榜/总榜
- **历史记录** - 按月查看学生行为记录

## 数据存储

- 数据保存在 `data.json` 文件中
- 重启服务后数据保留
- 备份此文件可防止数据丢失

## 端口修改

如需修改端口，编辑 `dist-server/server.js` 第47行：
```javascript
app.listen(5000, '0.0.0.0', () => {
```
将 `5000` 改为其他端口

## Nginx 反向代理配置（可选）

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## HTTPS 配置（推荐使用Let's Encrypt）

```bash
# 安装 certbot
sudo apt install certbot python3-certbot-nginx

# 获取证书
sudo certbot --nginx -d your-domain.com

# 自动续期
sudo certbot renew --dry-run
```
