(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))r(s);new MutationObserver(s=>{for(const o of s)if(o.type==="childList")for(const n of o.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&r(n)}).observe(document,{childList:!0,subtree:!0});function t(s){const o={};return s.integrity&&(o.integrity=s.integrity),s.referrerPolicy&&(o.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?o.credentials="include":s.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function r(s){if(s.ep)return;s.ep=!0;const o=t(s);fetch(s.href,o)}})();const I=[{title:"学习之星",minScore:100,icon:"📚",color:"text-yellow-500"},{title:"进步之星",minScore:50,icon:"🚀",color:"text-blue-500"},{title:"文明之星",minScore:30,icon:"🌟",color:"text-green-500"},{title:"劳动之星",minScore:20,icon:"🏆",color:"text-orange-500"},{title:"团结之星",minScore:10,icon:"🤝",color:"text-purple-500"}],D=[{id:"b1",name:"课堂积极发言",category:"positive",score:1,description:"在课堂上主动回答问题或提出疑问",icon:"✋"},{id:"b2",name:"作业优秀",category:"positive",score:3,description:"作业完成质量优秀",icon:"📝"},{id:"b3",name:"好人好事",category:"positive",score:5,description:"主动帮助他人，做了好事",icon:"🤝"},{id:"b4",name:"卫生打扫认真负责",category:"positive",score:2,description:"认真负责完成卫生打扫工作",icon:"🧹"},{id:"b5",name:"获得老师表扬",category:"positive",score:1,description:"因出色表现获得老师表扬",icon:"⭐"},{id:"b6",name:"竞赛获奖",category:"positive",score:5,description:"在校级及以上竞赛中获奖",icon:"🏆"},{id:"b7",name:"全勤",category:"positive",score:2,description:"当月无请假、无迟到、无旷课",icon:"✅"},{id:"b8",name:"单科成绩前3",category:"positive",score:3,description:"单科考试成绩排名班级前3名",icon:"📊"},{id:"b9",name:"全校前100",category:"positive",score:3,description:"考试成绩排名全校前100名",icon:"🎯"},{id:"b10",name:"进步50+",category:"positive",score:3,description:"成绩或表现进步显著，进步名次50名以上",icon:"📈"},{id:"n1",name:"迟到",category:"negative",score:-1,description:"上课或集会迟到",icon:"⏰"},{id:"n2",name:"旷课",category:"negative",score:-2,description:"无故缺课",icon:"❌"},{id:"n3",name:"作业未完成或抄袭",category:"negative",score:-2,description:"未按时完成作业或抄袭他人作业",icon:"📕"},{id:"n4",name:"上课说小话做小动作吃零食",category:"negative",score:-2,description:"上课（含自习课）说小话、做小动作、吃零食扰乱课堂秩序",icon:"⚠️"},{id:"n5",name:"顶撞老师",category:"negative",score:-10,description:"不尊重老师，顶撞老师",icon:"😠"},{id:"n6",name:"卫生不认真负责，逃避",category:"negative",score:-2,description:"逃避卫生劳动或不认真负责",icon:"🚫"},{id:"n7",name:"带手机、游戏机等电子产品",category:"negative",score:-5,description:"带电子产品到校玩耍或不服从班干部合理管理",icon:"📱"},{id:"n8",name:"乱扔垃圾、破坏公共卫生",category:"negative",score:-2,description:"乱扔垃圾或破坏公共卫生环境",icon:"🗑️"},{id:"n9",name:"给同学起侮辱性外号、嘲笑他人",category:"negative",score:-3,description:"侮辱、嘲笑他人",icon:"💢"},{id:"n10",name:"打架斗殴",category:"negative",score:-50,description:"与同学发生打架斗殴",icon:"💥"},{id:"n11",name:"带烟抽烟、偷窃等严重违纪",category:"negative",score:-20,description:"严重违纪行为",icon:"🚨"},{id:"n12",name:"故意损坏公物",category:"negative",score:-5,description:"故意损坏学校公共财物",icon:"🔨"}];function B(a){const e=new Date(a),t=e.getDay(),r=e.getDate()-t+(t===0?-6:1);return e.setDate(r),e.setHours(0,0,0,0),e}function R(a){return new Date(a.getFullYear(),a.getMonth(),1)}function A(a,e){const t=a.getTime(),r=e.getTime(),s=t+Math.random()*(r-t);return new Date(s).toISOString().split("T")[0]}function C(a,e){const t=A(a,e),r=Math.floor(Math.random()*9)+8,s=Math.floor(Math.random()*60);return`${t}T${r.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}:00`}const y=[{id:"s1",name:"张小明",class:"一年级一班",gender:"男",avatar:"👦",createdAt:"2024-09-01"},{id:"s2",name:"李小红",class:"一年级一班",gender:"女",avatar:"👧",createdAt:"2024-09-01"},{id:"s3",name:"王小强",class:"一年级二班",gender:"男",avatar:"👦",createdAt:"2024-09-01"},{id:"s4",name:"陈思思",class:"一年级二班",gender:"女",avatar:"👧",createdAt:"2024-09-01"},{id:"s5",name:"刘子轩",class:"一年级三班",gender:"男",avatar:"👦",createdAt:"2024-09-01"},{id:"s6",name:"赵雨萱",class:"一年级三班",gender:"女",avatar:"👧",createdAt:"2024-09-01"},{id:"s7",name:"孙浩然",class:"二年级一班",gender:"男",avatar:"👦",createdAt:"2024-09-01"},{id:"s8",name:"周雅琪",class:"二年级一班",gender:"女",avatar:"👧",createdAt:"2024-09-01"}],q=[1,3,5,2,1,5,2,3,3,3],O=[1,2,2,2,10,2,5,2,3,50,20,5],L=["b1","b2","b3","b4","b5","b6","b7","b8","b9","b10","n1","n2","n3","n4","n5","n6","n7","n8","n9","n10","n11","n12"];function V(){const a=[],e=new Date,t=new Date;t.setMonth(e.getMonth()-3);for(const r of y){const s=Math.floor(Math.random()*30)+20;for(let o=0;o<s;o++){const n=L[Math.floor(Math.random()*L.length)];a.push({id:`r${a.length+1}`,studentId:r.id,behaviorId:n,score:n.startsWith("b")?q[parseInt(n.slice(1))-1]:-O[parseInt(n.slice(1))-1],date:C(t,e)})}}return a}const S=V();function T(a,e){const t=e.filter(l=>l.studentId===a),r=new Date,s=B(r),o=R(r),n=t.filter(l=>new Date(l.date)>=s),i=t.filter(l=>new Date(l.date)>=o),u=t.filter(l=>l.score>0),g=t.filter(l=>l.score<0);return{totalScore:t.reduce((l,c)=>l+c.score,0),weeklyScore:n.reduce((l,c)=>l+c.score,0),monthlyScore:i.reduce((l,c)=>l+c.score,0),recordCount:t.length,positiveCount:u.length,negativeCount:g.length}}class H{constructor(){this.students=[...y],this.records=[...S],this.behaviors=D,this.listeners=new Set,this.currentView="dashboard",this.selectedStudentId=null,this.selectedMonth=this.getCurrentMonth(),this.initialized=!1,this.dataLoaded=!1,this.loadFromServer()}async loadFromServer(){try{const t=await(await fetch("/api/data")).json();t.success&&t.data&&(this.students=t.data.students||[...y],this.records=t.data.records||[...S],console.log("✅ 数据已从服务器加载")),this.dataLoaded=!0,this.initialized=!0,this.notify()}catch(e){console.error("❌ 加载数据失败，使用默认数据",e),this.dataLoaded=!0,this.initialized=!0}}async saveToServer(){try{await fetch("/api/data",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({students:this.students,records:this.records})})}catch(e){console.error("❌ 保存数据失败",e)}}async waitForData(){this.dataLoaded||await this.loadFromServer()}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}notify(){this.listeners.forEach(e=>e())}setView(e){this.currentView=e,e!=="studentDetail"&&(this.selectedStudentId=null),this.notify()}getView(){return this.currentView}selectStudent(e){this.selectedStudentId=e,e&&(this.currentView="studentDetail"),this.notify()}getSelectedStudentId(){return this.selectedStudentId}getStudents(){return[...this.students]}getStudentById(e){return this.students.find(t=>t.id===e)}addStudent(e){const t={...e,id:`s${Date.now()}`,createdAt:new Date().toISOString().split("T")[0]};return this.students.push(t),this.saveToServer(),this.notify(),t}updateStudent(e,t){const r=this.students.findIndex(s=>s.id===e);r!==-1&&(this.students[r]={...this.students[r],...t},this.saveToServer(),this.notify())}deleteStudent(e){this.students=this.students.filter(t=>t.id!==e),this.records=this.records.filter(t=>t.studentId!==e),this.selectedStudentId===e&&(this.selectedStudentId=null,this.currentView="dashboard"),this.saveToServer(),this.notify()}getRecords(){return[...this.records]}getRecordsByStudent(e){return this.records.filter(t=>t.studentId===e)}getBehaviors(){return[...this.behaviors]}getBehaviorById(e){return this.behaviors.find(t=>t.id===e)}addRecord(e){const t={...e,id:`r${Date.now()}`};return this.records.push(t),this.saveToServer(),this.notify(),t}deleteRecord(e){this.records=this.records.filter(t=>t.id!==e),this.saveToServer(),this.notify()}getAllStats(){const e=new Map;for(const t of this.students)e.set(t.id,{studentId:t.id,...T(t.id,this.records)});return e}getStudentStats(e){return{studentId:e,...T(e,this.records)}}getWeeklyLeaderboard(){const e=this.getAllStats();return this.students.map(t=>({...t,...e.get(t.id)})).sort((t,r)=>r.weeklyScore-t.weeklyScore).slice(0,10)}getMonthlyLeaderboard(e){if(!e){const r=this.getAllStats();return this.students.map(s=>({...s,...r.get(s.id)})).sort((s,o)=>o.monthlyScore-s.monthlyScore).slice(0,10)}const t=this.getMonthlyStats(e);return this.students.map(r=>{const s=t.get(r.id)||{records:[],totalScore:0};return{...r,monthlyScore:s.totalScore,recordCount:s.records.length}}).sort((r,s)=>s.monthlyScore-r.monthlyScore).slice(0,20)}getTotalLeaderboard(){const e=this.getAllStats();return this.students.map(t=>({...t,...e.get(t.id)})).sort((t,r)=>r.totalScore-t.totalScore).slice(0,10)}getStarTitle(e){for(const t of I)if(e>=t.minScore)return{title:t.title,icon:t.icon,color:t.color};return null}getStudentReport(e){const t=this.getStudentById(e);if(!t)return null;const r=this.getStudentStats(e),s=this.getStarTitle(r.totalScore),o=this.getRecordsByStudent(e).sort((l,c)=>new Date(c.date).getTime()-new Date(l.date).getTime()),n=o.slice(0,20),i=o.filter(l=>l.score>0),u=o.filter(l=>l.score<0),g=this.calculateWeeklyTrend(e);return{student:t,stats:r,starTitle:s,recentRecords:n,behaviorBreakdown:{positive:i.length,negative:u.length},weeklyTrend:g}}calculateWeeklyTrend(e){const t=this.records.filter(s=>s.studentId===e),r=new Map;for(const s of t){const o=new Date(s.date),i=this.getWeekStart(o).toISOString().split("T")[0];r.set(i,(r.get(i)||0)+s.score)}return Array.from(r.entries()).map(([s,o])=>({week:s,score:o})).sort((s,o)=>s.week.localeCompare(o.week)).slice(-8)}getWeekStart(e){const t=new Date(e),r=t.getDay(),s=t.getDate()-r+(r===0?-6:1);return t.setDate(s),t.setHours(0,0,0,0),t}getCurrentMonth(){const e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,"0")}`}setSelectedMonth(e){this.selectedMonth=e,this.notify()}getSelectedMonth(){return this.selectedMonth}getAvailableMonths(){const e=new Set;for(const t of this.records){const r=new Date(t.date),s=`${r.getFullYear()}-${String(r.getMonth()+1).padStart(2,"0")}`;e.add(s)}return e.add(this.getCurrentMonth()),Array.from(e).sort().reverse()}getMonthlyRecords(e){return this.records.filter(t=>{const r=new Date(t.date);return`${r.getFullYear()}-${String(r.getMonth()+1).padStart(2,"0")}`===e})}getStudentMonthlyRecords(e,t){return this.getMonthlyRecords(t).filter(r=>r.studentId===e)}getMonthlyStats(e){const t=this.getMonthlyRecords(e),r=new Map;for(const s of t){r.has(s.studentId)||r.set(s.studentId,{records:[],totalScore:0});const o=r.get(s.studentId);o.records.push(s),o.totalScore+=s.score}return r}getMonthlyHistory(){return this.getAvailableMonths().map(t=>{const r=this.getMonthlyRecords(t);return{month:t,totalRecords:r.length,totalScore:r.reduce((s,o)=>s+o.score,0)}})}addStudentsFromImport(e){let t=0;for(const r of e)if(!this.students.some(o=>o.name===r.name&&o.class===r.class)){const o=r.gender==="男"?"👦":"👧";this.students.push({...r,avatar:o,id:`s${Date.now()}_${Math.random().toString(36).substr(2,9)}`,createdAt:new Date().toISOString().split("T")[0]}),t++}return t>0&&(this.saveToServer(),this.notify()),t}resetToDefault(){this.students=[...y],this.records=[...S],this.saveToServer(),this.notify()}}const d=new H;async function F(){const a=document.getElementById("app");if(!a){console.error("App element not found");return}a.innerHTML=`
    <div class="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
      <div class="text-center">
        <div class="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p class="text-gray-600">正在加载数据...</p>
      </div>
    </div>
  `,await d.waitForData(),d.subscribe(M),M()}function M(){const a=document.getElementById("app");if(!a)return;const e=d.getView();a.innerHTML=`
    <div class="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <!-- 顶部导航 -->
      <header class="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-16">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-xl">
                📋
              </div>
              <h1 class="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                学生行为记录系统
              </h1>
            </div>
            <nav class="flex items-center gap-1">
              ${x("dashboard","仪表盘","📊")}
              ${x("students","学生管理","👥")}
              ${x("record","行为记录","✏️")}
              ${x("leaderboard","积分排行","🏆")}
              ${x("history","历史记录","📅")}
              ${x("report","分析报告","📈")}
            </nav>
          </div>
        </div>
      </header>

      <!-- 主内容区 -->
      <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        ${N(e)}
      </main>
    </div>
  `,$()}function x(a,e,t){const r=d.getView();return`
    <button 
      data-nav="${a}"
      class="nav-item px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${r===a||a==="report"&&r==="studentDetail"?"bg-blue-100 text-blue-700 shadow-sm":"text-gray-600 hover:bg-gray-100 hover:text-gray-900"}"
    >
      <span class="mr-1.5">${t}</span>
      ${e}
    </button>
  `}function N(a){switch(a){case"dashboard":return j();case"students":return W();case"record":return z();case"leaderboard":return _();case"history":return Q();case"studentDetail":return Y(d.getSelectedStudentId());case"report":return U();default:return j()}}function j(){const a=d.getAllStats(),e=d.getStudents().length,t=d.getRecords().length,r=Array.from(a.values()).reduce((n,i)=>n+i.totalScore,0)/e,s=d.getWeeklyLeaderboard(),o=d.getMonthlyLeaderboard();return`
    <div class="space-y-8">
      <!-- 统计卡片 -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500 mb-1">学生总数</p>
              <p class="text-3xl font-bold text-gray-900">${e}</p>
            </div>
            <div class="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center text-2xl">👥</div>
          </div>
        </div>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500 mb-1">行为记录</p>
              <p class="text-3xl font-bold text-gray-900">${t}</p>
            </div>
            <div class="w-14 h-14 bg-green-100 rounded-2xl flex items-center justify-center text-2xl">✏️</div>
          </div>
        </div>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500 mb-1">平均积分</p>
              <p class="text-3xl font-bold text-gray-900">${r.toFixed(1)}</p>
            </div>
            <div class="w-14 h-14 bg-yellow-100 rounded-2xl flex items-center justify-center text-2xl">📊</div>
          </div>
        </div>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500 mb-1">本周之星</p>
              ${s.length>0?`
                <p class="text-lg font-bold text-gray-900">${s[0].avatar} ${s[0].name}</p>
                <p class="text-sm text-yellow-600">+${s[0].weeklyScore}分</p>
              `:'<p class="text-lg text-gray-400">暂无</p>'}
            </div>
            <div class="w-14 h-14 bg-yellow-100 rounded-2xl flex items-center justify-center text-2xl">⭐</div>
          </div>
        </div>
      </div>

      <!-- 排行榜预览 -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- 周榜 -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <span>📅</span> 本周排行 TOP 5
            </h2>
            <button data-nav="leaderboard" class="text-sm text-blue-600 hover:text-blue-700 font-medium">查看全部 →</button>
          </div>
          <div class="divide-y divide-gray-50">
            ${s.slice(0,5).map((n,i)=>`
              <div class="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div class="flex items-center gap-4">
                  <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${i===0?"bg-yellow-100 text-yellow-700":i===1?"bg-gray-100 text-gray-700":i===2?"bg-orange-100 text-orange-700":"bg-gray-50 text-gray-500"}">${i+1}</div>
                  <span class="text-xl">${n.avatar}</span>
                  <div>
                    <p class="font-medium text-gray-900">${n.name}</p>
                    <p class="text-sm text-gray-500">${n.class}</p>
                  </div>
                </div>
                <div class="text-right">
                  <p class="font-bold ${n.weeklyScore>=0?"text-green-600":"text-red-600"}">${n.weeklyScore>=0?"+":""}${n.weeklyScore}</p>
                  <p class="text-xs text-gray-400">本周积分</p>
                </div>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- 月榜 -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <span>🗓️</span> 本月排行 TOP 5
            </h2>
            <button data-nav="leaderboard" class="text-sm text-blue-600 hover:text-blue-700 font-medium">查看全部 →</button>
          </div>
          <div class="divide-y divide-gray-50">
            ${o.slice(0,5).map((n,i)=>`
              <div class="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div class="flex items-center gap-4">
                  <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${i===0?"bg-yellow-100 text-yellow-700":i===1?"bg-gray-100 text-gray-700":i===2?"bg-orange-100 text-orange-700":"bg-gray-50 text-gray-500"}">${i+1}</div>
                  <span class="text-xl">${n.avatar}</span>
                  <div>
                    <p class="font-medium text-gray-900">${n.name}</p>
                    <p class="text-sm text-gray-500">${n.class}</p>
                  </div>
                </div>
                <div class="text-right">
                  <p class="font-bold ${n.monthlyScore>=0?"text-green-600":"text-red-600"}">${n.monthlyScore>=0?"+":""}${n.monthlyScore}</p>
                  <p class="text-xs text-gray-400">本月积分</p>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      </div>

      <!-- 快捷操作 -->
      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">快捷操作</h2>
        <div class="flex flex-wrap gap-4">
          <button data-action="quick-record" class="px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-blue-200 transition-all flex items-center gap-2">
            <span>✏️</span> 快速记录行为
          </button>
          <button data-action="add-student" class="px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-green-200 transition-all flex items-center gap-2">
            <span>➕</span> 添加学生
          </button>
          <button data-action="view-report" class="px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-purple-200 transition-all flex items-center gap-2">
            <span>📊</span> 查看分析报告
          </button>
        </div>
      </div>
    </div>
  `}function W(){const a=d.getStudents(),e=d.getAllStats();return`
    <div class="space-y-6">
      <div class="flex items-center justify-between">
        <h2 class="text-2xl font-bold text-gray-900">学生管理</h2>
        <div class="flex gap-3 flex-wrap">
          <button data-action="add-student-manual" class="px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-blue-200 transition-all flex items-center gap-2">
            <span>➕</span> 添加学生
          </button>
          <button data-action="import-students" class="px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-green-200 transition-all flex items-center gap-2">
            <span>📥</span> 表格导入
          </button>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        ${a.map(t=>{const r=e.get(t.id),s=d.getStarTitle(r.totalScore);return`
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all group">
              <div class="p-6">
                <div class="flex items-start justify-between mb-4">
                  <div class="flex items-center gap-3">
                    <div class="w-14 h-14 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl flex items-center justify-center text-3xl">
                      ${t.avatar}
                    </div>
                    <div>
                      <h3 class="font-semibold text-gray-900">${t.name}</h3>
                      <p class="text-sm text-gray-500">${t.class}</p>
                      <span class="inline-block mt-1 px-2 py-0.5 bg-gray-100 rounded text-xs text-gray-600">${t.gender}</span>
                    </div>
                  </div>
                </div>
                
                <div class="space-y-3">
                  <div class="flex items-center justify-between text-sm">
                    <span class="text-gray-500">总积分</span>
                    <span class="font-semibold ${r.totalScore>=0?"text-green-600":"text-red-600"}">${r.totalScore>=0?"+":""}${r.totalScore}</span>
                  </div>
                  <div class="flex items-center justify-between text-sm">
                    <span class="text-gray-500">本周</span>
                    <span class="font-semibold ${r.weeklyScore>=0?"text-green-600":"text-red-600"}">${r.weeklyScore>=0?"+":""}${r.weeklyScore}</span>
                  </div>
                  <div class="flex items-center justify-between text-sm">
                    <span class="text-gray-500">本月</span>
                    <span class="font-semibold ${r.monthlyScore>=0?"text-green-600":"text-red-600"}">${r.monthlyScore>=0?"+":""}${r.monthlyScore}</span>
                  </div>
                </div>

                ${s?`
                  <div class="mt-4 pt-4 border-t border-gray-100">
                    <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${s.color} bg-current/10">
                      ${s.icon} ${s.title}
                    </span>
                  </div>
                `:""}

                <div class="mt-4 flex gap-2">
                  <button data-action="view-student" data-id="${t.id}" class="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
                    查看详情
                  </button>
                  <button data-action="record-for" data-id="${t.id}" class="flex-1 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg text-sm font-medium hover:bg-blue-200 transition-colors">
                    记录行为
                  </button>
                </div>
                
                <div class="mt-3 pt-3 border-t border-gray-100">
                  <button data-action="delete-student" data-id="${t.id}" class="w-full px-4 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 hover:text-red-700 transition-colors flex items-center justify-center gap-2">
                    <span>🗑️</span> 删除学生
                  </button>
                </div>
              </div>
            </div>
          `}).join("")}
      </div>
    </div>
  `}function z(){const a=d.getStudents(),e=d.getBehaviors();return e.filter(t=>t.category==="positive"),e.filter(t=>t.category==="negative"),`
    <div class="max-w-2xl mx-auto space-y-6">
      <div class="text-center mb-8">
        <h2 class="text-2xl font-bold text-gray-900 mb-2">记录学生行为</h2>
        <p class="text-gray-500">选择学生和行为类型，系统将自动计算积分</p>
      </div>

      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 space-y-6">
        <!-- 学生选择 -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-3">
            <span class="flex items-center gap-2">
              <span>👤</span> 选择学生
            </span>
          </label>
          <select id="student-select" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white">
            <option value="">请选择学生...</option>
            ${a.map(t=>`
              <option value="${t.id}">${t.avatar} ${t.name} - ${t.class}</option>
            `).join("")}
          </select>
        </div>

        <!-- 行为类别 -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-3">
            <span class="flex items-center gap-2">
              <span>🏷️</span> 行为类型
            </span>
          </label>
          <div class="grid grid-cols-2 gap-4 mb-4">
            <button data-behavior-type="positive" class="behavior-type-btn px-4 py-3 rounded-xl border-2 border-gray-200 text-left hover:border-green-300 hover:bg-green-50 transition-all">
              <div class="flex items-center gap-2 mb-1">
                <span class="text-xl">👍</span>
                <span class="font-medium text-gray-900">正面行为</span>
              </div>
              <p class="text-xs text-gray-500">帮助、表扬、进步等</p>
            </button>
            <button data-behavior-type="negative" class="behavior-type-btn px-4 py-3 rounded-xl border-2 border-gray-200 text-left hover:border-red-300 hover:bg-red-50 transition-all">
              <div class="flex items-center gap-2 mb-1">
                <span class="text-xl">👎</span>
                <span class="font-medium text-gray-900">负面行为</span>
              </div>
              <p class="text-xs text-gray-500">迟到、违纪、违规等</p>
            </button>
          </div>
        </div>

        <!-- 行为选择 -->
        <div id="behavior-list" class="space-y-3">
          <p class="text-center text-gray-400 py-8">请先选择行为类型</p>
        </div>

        <!-- 积分预览 -->
        <div id="score-preview" class="hidden p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
          <div class="flex items-center justify-between">
            <span class="text-gray-600">本次积分变化</span>
            <span id="score-value" class="text-2xl font-bold text-blue-600">+0</span>
          </div>
        </div>

        <!-- 提交按钮 -->
        <button id="submit-record" disabled class="w-full py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-blue-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none flex items-center justify-center gap-2">
          <span>✨</span> 提交记录
        </button>
      </div>
    </div>
  `}function P(a,e){return a.map(t=>`
    <button data-behavior-id="${t.id}" class="behavior-option w-full px-4 py-3 rounded-xl border border-gray-200 text-left hover:border-blue-300 hover:bg-blue-50 transition-all ${e?"hover:bg-green-50 hover:border-green-300":"hover:bg-red-50 hover:border-red-300"}">
      <div class="flex items-center justify-between">
        <div>
          <p class="font-medium text-gray-900">${t.name}</p>
          <p class="text-sm text-gray-500">${t.description}</p>
        </div>
        <div class="text-right">
          <p class="text-lg font-bold ${t.score>=0?"text-green-600":"text-red-600"}">${t.score>=0?"+":""}${t.score}</p>
          <p class="text-xs text-gray-400">积分</p>
        </div>
      </div>
    </button>
  `).join("")}function _(){const a=d.getWeeklyLeaderboard();return d.getMonthlyLeaderboard(),d.getTotalLeaderboard(),`
    <div class="space-y-8">
      <div class="text-center mb-8">
        <h2 class="text-2xl font-bold text-gray-900 mb-2">积分排行榜</h2>
        <p class="text-gray-500">查看学生的积分排名和获得称号</p>
      </div>

      <!-- 切换标签 -->
      <div class="flex justify-center gap-4 mb-8">
        <button data-leaderboard-tab="weekly" class="leaderboard-tab px-6 py-3 rounded-xl font-medium bg-blue-100 text-blue-700">本周排行</button>
        <button data-leaderboard-tab="monthly" class="leaderboard-tab px-6 py-3 rounded-xl font-medium bg-gray-100 text-gray-600 hover:bg-gray-200">本月排行</button>
        <button data-leaderboard-tab="total" class="leaderboard-tab px-6 py-3 rounded-xl font-medium bg-gray-100 text-gray-600 hover:bg-gray-200">总排行</button>
      </div>

      <!-- 排行榜内容 -->
      <div id="leaderboard-content">
        ${f(a,"weekly")}
      </div>

      <!-- 称号说明 -->
      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <span>🏅</span> 学生称号说明
        </h3>
        <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div class="text-center p-4 bg-yellow-50 rounded-xl">
            <div class="text-3xl mb-2">📚</div>
            <p class="font-medium text-yellow-700">学习之星</p>
            <p class="text-sm text-yellow-600">100分+</p>
          </div>
          <div class="text-center p-4 bg-blue-50 rounded-xl">
            <div class="text-3xl mb-2">🚀</div>
            <p class="font-medium text-blue-700">进步之星</p>
            <p class="text-sm text-blue-600">50分+</p>
          </div>
          <div class="text-center p-4 bg-green-50 rounded-xl">
            <div class="text-3xl mb-2">🌟</div>
            <p class="font-medium text-green-700">文明之星</p>
            <p class="text-sm text-green-600">30分+</p>
          </div>
          <div class="text-center p-4 bg-orange-50 rounded-xl">
            <div class="text-3xl mb-2">🏆</div>
            <p class="font-medium text-orange-700">劳动之星</p>
            <p class="text-sm text-orange-600">20分+</p>
          </div>
          <div class="text-center p-4 bg-purple-50 rounded-xl">
            <div class="text-3xl mb-2">🤝</div>
            <p class="font-medium text-purple-700">团结之星</p>
            <p class="text-sm text-purple-600">10分+</p>
          </div>
        </div>
      </div>
    </div>
  `}function f(a,e){return`
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="divide-y divide-gray-100">
        ${a.map((t,r)=>{const s=d.getStarTitle(t.totalScore||0),o=e==="weekly"?t.weeklyScore||0:e==="monthly"?t.monthlyScore||0:t.totalScore||0,n=o>=0?"text-green-600":"text-red-600";return`
            <div class="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors cursor-pointer" data-student-link="${t.id}">
              <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold ${r===0?"bg-yellow-100 text-yellow-700 text-lg":r===1?"bg-gray-100 text-gray-700 text-lg":r===2?"bg-orange-100 text-orange-700 text-lg":"bg-gray-50 text-gray-500"}">
                  ${r===0?"🥇":r===1?"🥈":r===2?"🥉":r+1}
                </div>
                <span class="text-2xl">${t.avatar}</span>
                <div>
                  <p class="font-medium text-gray-900">${t.name}</p>
                  <p class="text-sm text-gray-500">${t.class}</p>
                </div>
              </div>
              <div class="flex items-center gap-6">
                ${s?`
                  <span class="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${s.color} bg-current/10">
                    ${s.icon} ${s.title}
                  </span>
                `:""}
                <div class="text-right">
                  <p class="text-xl font-bold ${n}">
                    ${o>=0?"+":""}${o}
                  </p>
                  <p class="text-xs text-gray-400">
                    ${e==="weekly"?"本周积分":e==="monthly"?"本月积分":"总积分"}
                  </p>
                </div>
              </div>
            </div>
          `}).join("")}
      </div>
    </div>
  `}function U(){return`
    <div class="space-y-6">
      <div class="text-center mb-8">
        <h2 class="text-2xl font-bold text-gray-900 mb-2">学生分析报告</h2>
        <p class="text-gray-500">选择学生查看详细的行为分析报告</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        ${d.getStudents().map(e=>`
          <button data-action="view-student-report" data-id="${e.id}" class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-left hover:shadow-md hover:border-blue-200 transition-all group">
            <div class="flex items-center gap-4 mb-4">
              <div class="w-16 h-16 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                ${e.avatar}
              </div>
              <div>
                <h3 class="font-semibold text-gray-900 text-lg">${e.name}</h3>
                <p class="text-sm text-gray-500">${e.class}</p>
              </div>
            </div>
            <div class="flex items-center justify-end text-blue-600 font-medium">
              查看报告 →
            </div>
          </button>
        `).join("")}
      </div>
    </div>
  `}function Y(a){const e=d.getStudentReport(a);if(!e)return'<p class="text-center text-gray-500">学生不存在</p>';const{student:t,stats:r,starTitle:s,recentRecords:o,behaviorBreakdown:n,weeklyTrend:i}=e,u=d.getBehaviors(),g=Math.max(...i.map(l=>Math.abs(l.score)),1);return`
    <div class="space-y-8">
      <!-- 返回按钮 -->
      <button data-action="back-to-report" class="flex items-center gap-2 text-gray-600 hover:text-gray-900 font-medium">
        <span>←</span> 返回报告选择
      </button>

      <!-- 学生概览 -->
      <div class="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-3xl p-8 text-white">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-6">
            <div class="w-24 h-24 bg-white/20 backdrop-blur rounded-3xl flex items-center justify-center text-5xl">
              ${t.avatar}
            </div>
            <div>
              <h2 class="text-3xl font-bold mb-2">${t.name}</h2>
              <p class="text-white/80">${t.class}</p>
              ${s?`
                <div class="mt-2 inline-flex items-center gap-2 px-4 py-1.5 bg-white/20 backdrop-blur rounded-full">
                  ${s.icon} <span>${s.title}</span>
                </div>
              `:""}
            </div>
          </div>
          <div class="text-right">
            <p class="text-5xl font-bold">${r.totalScore>=0?"+":""}${r.totalScore}</p>
            <p class="text-white/80">总积分</p>
          </div>
        </div>
      </div>

      <!-- 统计数据 -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-center">
          <p class="text-3xl font-bold text-green-600">+${r.positiveCount}</p>
          <p class="text-sm text-gray-500 mt-1">正面行为</p>
        </div>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-center">
          <p class="text-3xl font-bold text-red-600">${r.negativeCount}</p>
          <p class="text-sm text-gray-500 mt-1">负面行为</p>
        </div>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-center">
          <p class="text-3xl font-bold ${r.weeklyScore>=0?"text-blue-600":"text-red-600"}">${r.weeklyScore>=0?"+":""}${r.weeklyScore}</p>
          <p class="text-sm text-gray-500 mt-1">本周积分</p>
        </div>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 text-center">
          <p class="text-3xl font-bold ${r.monthlyScore>=0?"text-purple-600":"text-red-600"}">${r.monthlyScore>=0?"+":""}${r.monthlyScore}</p>
          <p class="text-sm text-gray-500 mt-1">本月积分</p>
        </div>
      </div>

      <!-- 行为趋势图 -->
      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
          <span>📈</span> 每周积分趋势
        </h3>
        ${i.length>0?`
          <div class="flex items-end justify-between gap-2 h-40">
            ${i.map(l=>{const c=Math.abs(l.score)/g*100,p=l.score>=0;return`
                <div class="flex-1 flex flex-col items-center gap-2">
                  <div class="w-full flex items-end justify-center" style="height: 100px;">
                    <div class="w-8 rounded-t-lg transition-all ${p?"bg-green-400":"bg-red-400"}" style="height: ${Math.max(c,5)}%;"></div>
                  </div>
                  <p class="text-xs text-gray-400">${l.week.slice(5)}</p>
                  <p class="text-sm font-medium ${p?"text-green-600":"text-red-600"}">${p?"+":""}${l.score}</p>
                </div>
              `}).join("")}
          </div>
        `:`
          <p class="text-center text-gray-400 py-12">暂无数据</p>
        `}
      </div>

      <!-- 最近行为记录 -->
      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
          <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <span>📋</span> 最近行为记录
          </h3>
        </div>
        <div class="divide-y divide-gray-50 max-h-96 overflow-y-auto">
          ${o.length>0?o.map(l=>{const c=u.find(p=>p.id===l.behaviorId);return`
              <div class="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div class="flex items-center gap-4">
                  <div class="w-10 h-10 rounded-full flex items-center justify-center ${c?.category==="positive"?"bg-green-100":"bg-red-100"}">
                    ${c?.category==="positive"?"👍":"👎"}
                  </div>
                  <div>
                    <p class="font-medium text-gray-900">${c?.name||"未知行为"}</p>
                    <p class="text-sm text-gray-500">${new Date(l.date).toLocaleDateString("zh-CN")}</p>
                  </div>
                </div>
                <p class="text-lg font-bold ${l.score>=0?"text-green-600":"text-red-600"}">${l.score>=0?"+":""}${l.score}</p>
              </div>
            `}).join(""):`
            <p class="text-center text-gray-400 py-12">暂无记录</p>
          `}
        </div>
      </div>

      <!-- 生成报告按钮 -->
      <div class="text-center">
        <button data-action="generate-report" data-id="${a}" class="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-blue-200 transition-all inline-flex items-center gap-2">
          <span>📄</span> 生成详细报告
        </button>
      </div>
    </div>
  `}function $(){document.querySelectorAll("[data-nav]").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.nav;d.setView(s)})}),document.querySelectorAll(".leaderboard-tab").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.leaderboardTab;document.querySelectorAll(".leaderboard-tab").forEach(i=>{i.classList.remove("bg-blue-100","text-blue-700"),i.classList.add("bg-gray-100","text-gray-600")}),r.currentTarget.classList.remove("bg-gray-100","text-gray-600"),r.currentTarget.classList.add("bg-blue-100","text-blue-700");const o=document.getElementById("leaderboard-content");let n="";switch(s){case"weekly":n=f(d.getWeeklyLeaderboard(),"weekly");break;case"monthly":n=f(d.getMonthlyLeaderboard(),"monthly");break;case"total":n=f(d.getTotalLeaderboard(),"total");break}o.innerHTML=n,$()})}),document.querySelectorAll("[data-student-link]").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.studentLink;d.selectStudent(s)})}),document.querySelectorAll(".month-btn").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.month;d.setSelectedMonth(s)})}),document.querySelectorAll("[data-student-history]").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.studentHistory,o=document.getElementById("student-monthly-detail"),n=d.getSelectedMonth(),i=d.getStudents().find(c=>c.id===s),u=d.getStudentMonthlyRecords(s,n);if(!i)return;const g=u.reduce((c,p)=>c+p.score,0),l=g>=0?"text-green-600":"text-red-600";o.classList.remove("hidden"),o.innerHTML=`
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mt-4">
          <div class="px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-green-50 to-blue-50">
            <div class="flex items-center justify-between">
              <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <span>${i.avatar}</span> ${i.name} - ${n.replace("-","年")}月 行为记录
              </h3>
              <span class="text-xl font-bold ${l}">${g>=0?"+":""}${g}分</span>
            </div>
            <p class="text-sm text-gray-500 mt-1">${i.class} · ${i.gender}</p>
          </div>
          ${u.length===0?`
            <div class="p-8 text-center text-gray-400">暂无本月行为记录</div>
          `:`
            <div class="divide-y divide-gray-50">
              ${u.map(c=>{const p=d.getBehaviors().find(h=>h.id===c.behaviorId),b=c.score>=0?"text-green-600":"text-red-600";return`
                  <div class="px-6 py-4 flex items-center justify-between hover:bg-gray-50">
                    <div class="flex items-center gap-4">
                      <span class="text-2xl">${p?.icon||"📋"}</span>
                      <div>
                        <p class="font-medium text-gray-900">${p?.name||"未知行为"}</p>
                        <p class="text-sm text-gray-500">${c.date}</p>
                      </div>
                    </div>
                    <span class="text-lg font-bold ${b}">${c.score>=0?"+":""}${c.score}</span>
                  </div>
                `}).join("")}
            </div>
          `}
        </div>
      `})}),document.querySelectorAll("[data-action]").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.action;K(s,r.currentTarget)})}),document.querySelectorAll(".behavior-type-btn").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.behaviorType,o=d.getBehaviors().filter(i=>i.category===s),n=document.getElementById("behavior-list");n.innerHTML=P(o,s==="positive"),$()})}),document.querySelectorAll(".behavior-option").forEach(t=>{t.addEventListener("click",r=>{const s=r.currentTarget.dataset.behaviorId,o=d.getBehaviorById(s);if(!o)return;document.querySelectorAll(".behavior-option").forEach(l=>{l.classList.remove("border-blue-400","bg-blue-50","border-red-400","bg-red-50")}),r.currentTarget.classList.add("border-2"),o.category==="positive"?r.currentTarget.classList.add("border-green-400","bg-green-50"):r.currentTarget.classList.add("border-red-400","bg-red-50");const n=document.getElementById("score-preview"),i=document.getElementById("score-value");n.classList.remove("hidden"),i.textContent=`${o.score>=0?"+":""}${o.score}`,i.className=`text-2xl font-bold ${o.score>=0?"text-green-600":"text-red-600"}`;const u=document.getElementById("submit-record"),g=document.getElementById("student-select");u.disabled=!g.value,u.dataset.selectedBehavior=s})});const a=document.getElementById("student-select");a&&a.addEventListener("change",()=>{const t=document.getElementById("submit-record");t.disabled=!a.value||!t.dataset.selectedBehavior});const e=document.getElementById("submit-record");e&&e.addEventListener("click",()=>{const t=document.getElementById("student-select").value,r=e.dataset.selectedBehavior,s=d.getBehaviorById(r);if(!t||!r||!s){alert("请选择学生和行为类型");return}d.addRecord({studentId:t,behaviorId:r,score:s.score,date:new Date().toISOString()}),alert("记录成功！"),d.setView("dashboard")})}function K(a,e){switch(a){case"quick-record":d.setView("record");break;case"add-student":E();break;case"view-report":d.setView("report");break;case"view-student":d.selectStudent(e.dataset.id);break;case"record-for":d.setView("record"),setTimeout(()=>{const t=document.getElementById("student-select");t&&(t.value=e.dataset.id,t.dispatchEvent(new Event("change")))},100);break;case"delete-student":G(e.dataset.id);break;case"view-student-report":d.selectStudent(e.dataset.id);break;case"back-to-report":d.setView("report");break;case"generate-report":J(e.dataset.id);break;case"import-students":Z();break;case"add-student-manual":E();break}}function E(){const a=document.createElement("div");a.id="add-student-modal",a.className="fixed inset-0 bg-black/50 flex items-center justify-center z-50",a.innerHTML=`
    <div class="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md mx-4">
      <h3 class="text-xl font-bold text-gray-900 mb-6">添加新学生</h3>
      <form id="add-student-form" class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">姓名</label>
          <input type="text" name="name" required class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="请输入学生姓名">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">班级</label>
          <input type="text" name="class" required class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="如：一班">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">性别</label>
          <div class="flex gap-4">
            <label class="cursor-pointer flex-1">
              <input type="radio" name="gender" value="男" checked class="hidden peer">
              <div class="w-full py-3 text-center border-2 border-gray-200 rounded-xl peer-checked:border-blue-500 peer-checked:bg-blue-50 hover:border-gray-300 transition-all font-medium">
                👦 男
              </div>
            </label>
            <label class="cursor-pointer flex-1">
              <input type="radio" name="gender" value="女" class="hidden peer">
              <div class="w-full py-3 text-center border-2 border-gray-200 rounded-xl peer-checked:border-blue-500 peer-checked:bg-blue-50 hover:border-gray-300 transition-all font-medium">
                👧 女
              </div>
            </label>
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">头像</label>
          <div class="grid grid-cols-6 gap-2">
            ${["👦","👧","🧑","👱","🧒","👶","🧒","👨","👩","🧔","👴","👵"].map(e=>`
              <label class="cursor-pointer">
                <input type="radio" name="avatar" value="${e}" class="hidden peer">
                <div class="w-12 h-12 rounded-xl flex items-center justify-center text-2xl border-2 border-gray-200 peer-checked:border-blue-500 peer-checked:bg-blue-50 hover:border-gray-300 transition-all">
                  ${e}
                </div>
              </label>
            `).join("")}
          </div>
        </div>
        <div class="flex gap-4 pt-4">
          <button type="button" data-action="close-modal" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
            取消
          </button>
          <button type="submit" class="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-medium hover:shadow-lg transition-all">
            保存
          </button>
        </div>
      </form>
    </div>
  `,document.body.appendChild(a),a.querySelector('input[name="avatar"]').checked=!0,a.querySelector('[data-action="close-modal"]')?.addEventListener("click",()=>{a.remove()}),a.addEventListener("click",e=>{e.target===a&&a.remove()}),a.querySelector("#add-student-form")?.addEventListener("submit",e=>{e.preventDefault();const t=e.target,r=new FormData(t),s=r.get("gender")||"男";d.addStudent({name:r.get("name"),class:r.get("class"),gender:s,avatar:r.get("avatar")||"👦"}),a.remove(),d.setView("students")})}function J(a){const e=d.getStudentReport(a);if(!e)return;const t=`
╔══════════════════════════════════════════════════════════════════════════════╗
║                          学 生 行 为 分 析 报 告                               ║
╠══════════════════════════════════════════════════════════════════════════════╣
│ 学生姓名: ${e.student.name}                                                     │
│ 所在班级: ${e.student.class}                                                     │
│ 报告生成: ${new Date().toLocaleDateString("zh-CN")}                                                    │
╠══════════════════════════════════════════════════════════════════════════════╣
│                                  基 本 信 息                                   │
├──────────────────────────────────────────────────────────────────────────────┤
│ ${e.student.avatar} 综合积分: ${e.student.avatar}${e.stats.totalScore>=0?"+":""}${e.stats.totalScore} 分                                           │
│ ${e.student.avatar} 本周积分: ${e.student.avatar}${e.stats.weeklyScore>=0?"+":""}${e.stats.weeklyScore} 分                                           │
│ ${e.student.avatar} 本月积分: ${e.student.avatar}${e.stats.monthlyScore>=0?"+":""}${e.stats.monthlyScore} 分                                           │
│ ${e.student.avatar} 获得称号: ${e.starTitle?e.starTitle.icon+" "+e.starTitle.title:"暂无"}                                        │
├──────────────────────────────────────────────────────────────────────────────┤
│                                  行为统计                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│ 正面行为次数: ${e.behaviorBreakdown.positive} 次                                                 │
│ 负面行为次数: ${e.behaviorBreakdown.negative} 次                                                 │
│ 行为记录总数: ${e.stats.recordCount} 条                                                 │
╠══════════════════════════════════════════════════════════════════════════════╣
│                                近 期 行 为 记 录                                │
${e.recentRecords.slice(0,10).map((n,i)=>{const u=d.getBehaviorById(n.behaviorId);return`│ ${(i+1).toString().padStart(2)}. ${u?.name||"未知"}(${n.score>=0?"+":""}${n.score}分) - ${new Date(n.date).toLocaleDateString("zh-CN")}`.padEnd(80)+"│"}).join(`
`)}
╠══════════════════════════════════════════════════════════════════════════════╣
║                              报 告 结 束                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
  `,r=new Blob([t],{type:"text/plain;charset=utf-8"}),s=URL.createObjectURL(r),o=document.createElement("a");o.href=s,o.download=`${e.student.name}_行为分析报告_${new Date().toISOString().split("T")[0]}.txt`,o.click(),URL.revokeObjectURL(s)}const X="86713279";function G(a){const e=document.createElement("div");e.id="delete-confirm-modal",e.className="fixed inset-0 bg-black/50 flex items-center justify-center z-50",e.innerHTML=`
    <div class="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md mx-4">
      <div class="text-center mb-6">
        <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <span class="text-3xl">⚠️</span>
        </div>
        <h3 class="text-xl font-bold text-gray-900 mb-2">确认删除学生</h3>
        <p class="text-gray-500">删除后所有相关记录也将被删除，此操作不可恢复。</p>
      </div>
      <form id="delete-form" class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">请输入管理员密码确认删除</label>
          <input type="password" id="delete-password" required class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500" placeholder="请输入密码">
        </div>
        <p id="password-error" class="text-red-500 text-sm hidden">密码错误，请重试</p>
        <div class="flex gap-4 pt-2">
          <button type="button" data-action="close-modal" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
            取消
          </button>
          <button type="submit" class="flex-1 px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl font-medium hover:shadow-lg transition-all">
            确认删除
          </button>
        </div>
      </form>
    </div>
  `,document.body.appendChild(e),e.querySelector('[data-action="close-modal"]')?.addEventListener("click",()=>{e.remove()}),e.addEventListener("click",t=>{t.target===e&&e.remove()}),e.querySelector("#delete-form")?.addEventListener("submit",t=>{t.preventDefault();const r=e.querySelector("#delete-password"),s=e.querySelector("#password-error");r.value===X?(d.deleteStudent(a),e.remove()):(s.classList.remove("hidden"),r.value="",r.focus())})}function Q(){const a=d.getAvailableMonths(),e=d.getSelectedMonth();return d.getMonthlyHistory(),`
    <div class="space-y-6">
      <div class="text-center mb-8">
        <h2 class="text-2xl font-bold text-gray-900 mb-2">历史记录</h2>
        <p class="text-gray-500">查看每月学生行为记录汇总</p>
      </div>

      <!-- 月份选择 -->
      <div class="flex flex-wrap gap-3 justify-center">
        ${a.map(t=>{const r=t===e,s=t.replace("-","年")+"月";return`
            <button data-month="${t}" class="month-btn px-4 py-2 rounded-xl font-medium transition-all ${r?"bg-blue-100 text-blue-700 shadow-sm":"bg-gray-100 text-gray-600 hover:bg-gray-200"}">
              ${s}
            </button>
          `}).join("")}
      </div>

      <!-- 学生名单 -->
      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-purple-50">
          <h3 class="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <span>👥</span> ${e.replace("-","年")}月 学生名单
          </h3>
          <p class="text-sm text-gray-500 mt-1">点击学生姓名查看该月行为记录</p>
        </div>
        <div class="divide-y divide-gray-50">
          ${(()=>{const t=d.getStudents();return t.length===0?'<p class="text-center text-gray-400 py-12">暂无学生数据</p>':t.map((r,s)=>{const o=d.getStudentMonthlyRecords(r.id,e),n=o.reduce((u,g)=>u+g.score,0),i=n>=0?"text-green-600":"text-red-600";return`
                <div class="px-6 py-4 flex items-center justify-between hover:bg-blue-50 transition-colors cursor-pointer" data-student-history="${r.id}">
                  <div class="flex items-center gap-4">
                    <span class="text-xl">${r.avatar}</span>
                    <div>
                      <p class="font-medium text-gray-900">${r.name}</p>
                      <p class="text-sm text-gray-500">${r.class} · ${r.gender}</p>
                    </div>
                  </div>
                  <div class="flex items-center gap-4">
                    <span class="text-sm ${o.length>0?"text-gray-600":"text-gray-400"}">
                      ${o.length}条记录
                    </span>
                    <span class="text-lg font-bold ${i}">
                      ${n>=0?"+":""}${n}
                    </span>
                  </div>
                </div>
              `}).join("")})()}
        </div>
      </div>
      
      <!-- 学生月度记录详情 -->
      <div id="student-monthly-detail" class="hidden"></div>
    </div>
  `}function Z(){const a=document.createElement("div");a.id="import-modal",a.className="fixed inset-0 bg-black/50 flex items-center justify-center z-50",a.innerHTML=`
    <div class="bg-white rounded-2xl shadow-xl p-8 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
      <h3 class="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
        <span>📥</span> 批量导入学生
      </h3>
      
      <div class="mb-6 p-4 bg-blue-50 rounded-xl">
        <p class="text-sm text-blue-800 font-medium mb-2">导入说明：</p>
        <ul class="text-sm text-blue-700 space-y-1">
          <li>支持 CSV、TXT、Excel 格式</li>
          <li>格式：班级,姓名,性别（例：一年级一班,张三,男）</li>
          <li>每行一条学生信息，性别填写"男"或"女"</li>
          <li>姓名和班级不能为空</li>
        </ul>
      </div>

      <div class="mb-6">
        <label class="block text-sm font-medium text-gray-700 mb-2">粘贴学生数据</label>
        <textarea id="import-data" rows="10" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono text-sm" placeholder="一年级一班,张三,男
一年级一班,李四,女
二年级一班,王五,男"></textarea>
      </div>

      <div id="preview-section" class="hidden mb-6">
        <p class="text-sm font-medium text-gray-700 mb-2">预览（共 <span id="preview-count">0</span> 名学生）：</p>
        <div class="max-h-48 overflow-y-auto border border-gray-200 rounded-xl">
          <table class="w-full text-sm">
            <thead class="bg-gray-50 sticky top-0">
              <tr>
                <th class="px-4 py-2 text-left font-medium text-gray-600">班级</th>
                <th class="px-4 py-2 text-left font-medium text-gray-600">姓名</th>
                <th class="px-4 py-2 text-left font-medium text-gray-600">性别</th>
              </tr>
            </thead>
            <tbody id="preview-body" class="divide-y divide-gray-100"></tbody>
          </table>
        </div>
      </div>

      <div id="import-result" class="hidden mb-6 p-4 rounded-xl"></div>

      <div class="flex gap-4">
        <button data-action="close-modal" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
          取消
        </button>
        <button id="preview-btn" class="flex-1 px-4 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors">
          预览
        </button>
        <button id="import-btn" disabled class="flex-1 px-4 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed">
          确认导入
        </button>
      </div>
    </div>
  `,document.body.appendChild(a);const e=a.querySelector("#import-data"),t=a.querySelector("#preview-section"),r=a.querySelector("#preview-body"),s=a.querySelector("#preview-count"),o=a.querySelector("#preview-btn"),n=a.querySelector("#import-btn"),i=a.querySelector("#import-result");let u=[];o.addEventListener("click",()=>{const g=e.value.trim();if(!g){alert("请输入学生数据");return}u=[];const l=g.split(`
`).filter(b=>b.trim()),c=[],p=[];if(l.forEach((b,h)=>{const v=b.split(/[,，\t]/).map(m=>m.trim()).filter(m=>m);if(v.length>=3){const m=v[0],k=v[1],w=v[2];k&&m&&(w==="男"||w==="女")?c.push({name:k,class:m,gender:w}):p.push(`第${h+1}行：性别必须是"男"或"女"`)}else v.length>0&&p.push(`第${h+1}行：格式错误，需要 班级,姓名,性别`)}),u=c,p.length>0&&c.length===0){i.className="hidden mb-6 p-4 rounded-xl",alert(`数据格式错误：
`+p.join(`
`));return}s.textContent=String(u.length),r.innerHTML=u.map(b=>`
      <tr>
        <td class="px-4 py-2">${b.class}</td>
        <td class="px-4 py-2 font-medium">${b.name}</td>
        <td class="px-4 py-2">
          <span class="px-2 py-0.5 bg-gray-100 rounded text-xs">${b.gender}</span>
        </td>
      </tr>
    `).join(""),t.classList.remove("hidden"),n.disabled=u.length===0,p.length>0&&(i.className="mb-6 p-4 bg-yellow-50 rounded-xl text-sm text-yellow-700",i.innerHTML=`<strong>部分数据跳过：</strong><br>${p.slice(0,5).join("<br>")}${p.length>5?"<br>...":""}`)}),n.addEventListener("click",()=>{if(u.length===0)return;const g=d.addStudentsFromImport(u);i.className="mb-6 p-4 bg-green-50 rounded-xl text-sm text-green-700",i.innerHTML=`<strong>导入成功！</strong><br>成功导入 ${g} 名学生${g<u.length?`<br>（${u.length-g} 名已存在，自动跳过）`:""}`,n.disabled=!0,o.disabled=!0,e.disabled=!0,setTimeout(()=>{a.remove()},1500)}),a.querySelector('[data-action="close-modal"]')?.addEventListener("click",()=>{a.remove()}),a.addEventListener("click",g=>{g.target===a&&a.remove()})}document.addEventListener("DOMContentLoaded",async()=>{await F()});
