#!/bin/bash
# 学生行为记录系统 - 生产环境启动脚本

echo "======================================"
echo "  学生行为记录系统 - 启动中..."
echo "======================================"

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "错误: 未找到 Node.js，请先安装 Node.js 20+"
    exit 1
fi

echo "Node.js 版本: $(node -v)"

# 安装依赖
echo "安装依赖..."
npm install

# 启动服务
echo ""
echo "启动服务在端口 5000..."
echo "访问地址: http://localhost:5000"
echo "按 Ctrl+C 停止服务"
echo "======================================"

node dist-server/server.js
